package com.example.fuelapp.controller;

import com.example.fuelapp.model.Available;
import com.example.fuelapp.service.AvailableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AvailableController {

    @Autowired
    AvailableService availableService;

    @PostMapping("/saveavailablefuel")
    public ResponseEntity<Available> saveAvailableFuel(@RequestBody Available available){
        return availableService.saveAvailableFuel(available);
    }
}
