package com.example.fuelapp.service;

import com.example.fuelapp.model.Reserved;
import com.example.fuelapp.repository.ReservedRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReservedServiceImpl implements ReservedService{

    @Autowired
    ReservedRepo reservedRepo;

    @Override
    public Reserved saveReserved(Reserved reserved) {

        return reservedRepo.save(reserved);
    }

    @Override
    public Reserved getFromAvailable(int orderRefId, String fuelType, int fuelCapacity) {
        Reserved reserved = new Reserved();
        reserved.setOrderRefId(orderRefId);
        reserved.setFuelType(fuelType);
        reserved.setQuantity(fuelCapacity);
        return saveReserved(reserved);


    }
}
