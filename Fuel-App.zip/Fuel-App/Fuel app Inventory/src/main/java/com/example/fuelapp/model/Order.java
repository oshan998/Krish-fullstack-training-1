package com.example.fuelapp.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Order")
public class Order {


    @Id
    private int orderRefId;
    private String name;
    private int sId;
    private String location;
    private int capacity;
    private String fuelType;
    private String status="order pending";


    public Order() {}

    public Order(int orderRefId, String name, int sId, String location, int capacity, String fuelType, String status) {
        super();
        this.orderRefId = orderRefId;
        this.name = name;
        this.sId = sId;
        this.location = location;
        this.capacity = capacity;
        this.fuelType = fuelType;
        this.status = status;
    }

    public int getOrderRefId() {
        return orderRefId;
    }

    public void setOrderRefId(int orderRefId) {
        this.orderRefId = orderRefId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getsId() {
        return sId;
    }

    public void setsId(int sId) {
        this.sId = sId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

