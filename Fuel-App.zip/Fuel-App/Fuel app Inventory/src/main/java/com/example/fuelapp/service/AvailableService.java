package com.example.fuelapp.service;

import com.example.fuelapp.model.Available;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;

public interface AvailableService {

    public ResponseEntity<Available> saveAvailableFuel(Available available);
    public Available getCapacity( String fuelType, int fuelCapacity,int orderRefId);
}
