package com.example.fuelapp.service;

import com.example.fuelapp.model.Reserved;

public interface ReservedService {

    public Reserved saveReserved(Reserved reserved);

    public Reserved getFromAvailable(int orderRefId, String fuelType, int fuelCapacity);
}
