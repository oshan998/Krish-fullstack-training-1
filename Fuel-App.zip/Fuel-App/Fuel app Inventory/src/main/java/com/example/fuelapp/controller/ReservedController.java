package com.example.fuelapp.controller;

public class ReservedController {
}
