package com.example.fuelapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuelappOrderApplicationTests {

    @Test
    void contextLoads() {
    }

}
