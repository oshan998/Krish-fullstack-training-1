package com.example.fuelapp.controller;

import com.example.fuelapp.model.Order;
import com.example.fuelapp.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController

@RequestMapping("api/v1/order")
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class OrderController {

    @Autowired
    OrderService orderService;

    @PostMapping
    public ResponseEntity<Order> placeOrder(@RequestBody Order order){
        return orderService.saveOrder(order);
    }


    @GetMapping("/{sId}")
    public ResponseEntity<List<Order>> getOrder(@PathVariable int sId){
        return orderService.getOrder(sId);
    }

    @PutMapping("/{id}/{status}")
    public ResponseEntity<Order> orderReceived(@PathVariable int id, @PathVariable String status){
        return orderService.orderReceived(id,status);
    }

    @GetMapping
    public ResponseEntity<List<Order>> getAllOrders(){
        return orderService.getAllOrders();
    }

}
