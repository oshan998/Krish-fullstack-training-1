package com.example.fuelapp.service;

import com.example.fuelapp.model.Order;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Optional;

public interface OrderService {

    public ResponseEntity<Order> saveOrder(Order order);

    public  ResponseEntity<List<Order>> getOrder(int sId);

    public ResponseEntity<List<Order>> getAllOrders();

    public ResponseEntity<Order> orderReceived(int id, String status);
}
