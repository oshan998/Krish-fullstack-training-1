package com.example.fuelapp.service;

import com.example.fuelapp.config.KafkaTopicConfig;
import com.example.fuelapp.model.Order;
import com.example.fuelapp.repository.OrderRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Random;


@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    OrderRepo orderRepo;

    @Autowired
    KafkaTemplate<String, Order> kafkaTemplate;

    @Override
    public ResponseEntity<Order> saveOrder(Order order){

        //generate random number for orderrefid
        Random random = new Random();
        int y = random.nextInt(3000);

        try{
            order.setOrderRefId(y);
            kafkaTemplate.send(KafkaTopicConfig.MESSAGE_TOPIC, order);
            orderRepo.save(order);
        }catch (Exception e){

        }

        return ResponseEntity.status(HttpStatus.OK).body(order);
    }

    @Override
    public ResponseEntity<List<Order>> getOrder(int sId) {

        return ResponseEntity.status(HttpStatus.OK).body(orderRepo.findBysId(sId));
    }

    @Override
    public ResponseEntity<List<Order>> getAllOrders(){

        return ResponseEntity.status(HttpStatus.OK).body(orderRepo.findAll());
    }

    @Override
    public ResponseEntity<Order> orderReceived(int id, String status){


        Optional<Order> byId = orderRepo.findById(id);
        if(byId.isPresent()) {
            Order order = byId.get();
            order.setStatus(status);

            orderRepo.save(order);

            return ResponseEntity.status(HttpStatus.OK).body(order);
        }else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

}
