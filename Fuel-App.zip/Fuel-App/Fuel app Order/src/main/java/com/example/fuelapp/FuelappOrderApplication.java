package com.example.fuelapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
//@EnableEurekaClient
public class FuelappOrderApplication {

    public static void main(String[] args) {
        SpringApplication.run(FuelappOrderApplication.class, args);
    }

}
