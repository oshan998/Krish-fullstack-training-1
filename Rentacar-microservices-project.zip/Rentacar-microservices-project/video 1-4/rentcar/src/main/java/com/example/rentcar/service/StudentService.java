package com.example.rentcar.service;

import com.example.rentcar.model.Student;

public interface StudentService {

    Student save(Student student);
}
