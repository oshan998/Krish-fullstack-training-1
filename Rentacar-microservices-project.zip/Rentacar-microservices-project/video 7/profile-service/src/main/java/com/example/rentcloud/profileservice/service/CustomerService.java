package com.example.rentcloud.profileservice.service;

import org.example.rentcloud.commons.model.Customer;

public interface CustomerService {

    Customer save(Customer customer);
}
