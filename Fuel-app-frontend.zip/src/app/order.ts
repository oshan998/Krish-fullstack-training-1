export class Order {
    orderRefId !: number;
    name !: string;
    sId !: number;
    location !: string;
    capacity !: number;
    fuelType !: string;
    status !: string;
}
