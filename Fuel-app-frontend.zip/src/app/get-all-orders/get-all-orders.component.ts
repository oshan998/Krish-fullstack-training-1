import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {Order} from '../order'
import { OrderService } from '../order.service';
@Component({
  selector: 'app-get-all-orders',
  templateUrl: './get-all-orders.component.html',
  styleUrls: ['./get-all-orders.component.css']
})
export class GetAllOrdersComponent implements OnInit {

  orders!: Order[];
  constructor(private orderService: OrderService,
    private router: Router) { }

  ngOnInit(): void {
    this.getOrders();
  }

  private getOrders(){
    this.orderService.getAllOrders().subscribe(data =>{
      this.orders = data;
    })
  }

  orderReceived(sId: number){
    this.router.navigate(['orderreceived',sId]);
  }
}
