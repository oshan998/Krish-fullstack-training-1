import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Order } from '../order';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.css']
})
export class PlaceOrderComponent implements OnInit {

  order: Order=new Order();

  constructor(private orderService: OrderService,
    private router: Router) { }

  ngOnInit(): void {
  }

  saveOrder(){
    this.orderService.placeOrder(this.order).subscribe( data =>{
      console.log(data);
      this.goToOrders();
    },
    error => console.log(error));
  }

  goToOrders(){
    this.router.navigate(['/orders']);
  }

  onSubmit(){
    console.log(this.order);
    this.saveOrder();
  }

}

