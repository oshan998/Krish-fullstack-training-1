
enum CarType{
    SEDAN,SUV,HATCHBACK
}