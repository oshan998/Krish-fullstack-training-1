class SedanCar extends Car{

    public SedanCar(Location location) {
        super(CarType.SEDAN, location);
        construct();
    }

    protected void construct(){
        System.out.println("Sedan car");
    }
}