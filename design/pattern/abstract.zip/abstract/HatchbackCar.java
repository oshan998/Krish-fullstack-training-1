class HatchbackCar extends Car{

public HatchbackCar(Location location) {
        super(CarType.HATCHBACK, location);
        construct();
        }

protected void construct(){
        System.out.println("Hatchback car");
        }
        }