class UsaCarFactory
{
    static Car buildCar(CarType model)
    {
        Car car = null;
        switch (model)
        {
            case SEDAN:
                car = new SedanCar(Location.USA);
                break;

            case SUV:
                car = new SuvCar(Location.USA);
                break;

            case HATCHBACK:
                car = new HatchbackCar(Location.USA);
                break;

            default:
                break;

        }
        return car;
    }
}