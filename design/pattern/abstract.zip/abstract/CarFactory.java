class CarFactory
{
    private CarFactory()
    {

    }
    public static Car buildCar(CarType type)
    {
        Car car = null;

        Location location = Location.ITALY;

        switch(location)
        {
            case ITALY:
                car = ItalyCarFactory.buildCar(type);
                break;

            case GERMANY:
                car = GermanyCarFactory.buildCar(type);
                break;

            default:
                car = UsaCarFactory.buildCar(type);

        }

        return car;

    }
}