class ItalyCarFactory
{
    static Car buildCar(CarType model)
    {
        Car car = null;
        switch (model)
        {
            case SEDAN:
                car = new SedanCar(Location.ITALY);
                break;

            case SUV:
                car = new SuvCar(Location.ITALY);
                break;

            case HATCHBACK:
                car = new HatchbackCar(Location.ITALY);
                break;

            default:
                break;

        }
        return car;
    }
}