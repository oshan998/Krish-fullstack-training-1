class SuvCar extends Car{

    public SuvCar(Location location) {
        super(CarType.SUV, location);
        construct();
    }

    protected void construct(){
        System.out.println("SUV car");
    }
}