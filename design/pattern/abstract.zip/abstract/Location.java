enum Location{
    ITALY,GERMANY,USA;
}