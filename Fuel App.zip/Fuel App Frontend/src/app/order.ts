export class Order {
    orderRefId !: number;
    name !: string;
    shedId !: number;
    location !: string;
    capacity !: number;
    fuelType !: string;
    status !: string;
    date!:string;
}
