import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CheckOrdersComponent } from './check-orders/check-orders.component';
import { DispatchComponent } from './dispatch/dispatch.component';
import { GetAllOrdersComponent } from './get-all-orders/get-all-orders.component';
//import { OrderReceivedComponent } from './order-received/order-received.component';
import { PlaceOrderComponent } from './place-order/place-order.component';
import { UpdateOrderReceivedComponent } from './update-order-received/update-order-received.component';

const routes: Routes = [
  {path: 'orders', component: GetAllOrdersComponent},
  {path: 'placeorder', component: PlaceOrderComponent},
  {path: '', redirectTo: 'orders', pathMatch: 'full'},
  {path: 'getorderscomplete', component: UpdateOrderReceivedComponent},
  {path: 'getorders', component: CheckOrdersComponent},
  {path: 'dispatch', component: DispatchComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
