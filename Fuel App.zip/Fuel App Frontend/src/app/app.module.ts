import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GetAllOrdersComponent } from './get-all-orders/get-all-orders.component';
import { FormsModule } from '@angular/forms';
import { PlaceOrderComponent } from './place-order/place-order.component';
import { CheckOrdersComponent } from './check-orders/check-orders.component';
import { UpdateOrderReceivedComponent } from './update-order-received/update-order-received.component';
import { DispatchComponent } from './dispatch/dispatch.component';

@NgModule({
  declarations: [
    AppComponent,
    GetAllOrdersComponent,
    PlaceOrderComponent,
    CheckOrdersComponent,
    UpdateOrderReceivedComponent,
    DispatchComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
