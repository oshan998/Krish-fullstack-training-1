export class Dispatch {
    orderRefId!:number;
    date!:string;
}