import { Dispatch } from './dispatch';

describe('Dispatch', () => {
  it('should create an instance', () => {
    expect(new Dispatch()).toBeTruthy();
  });
});