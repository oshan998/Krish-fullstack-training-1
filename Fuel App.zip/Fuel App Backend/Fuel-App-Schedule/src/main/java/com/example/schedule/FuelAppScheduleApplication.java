package com.example.schedule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FuelAppScheduleApplication {

	public static void main(String[] args) {
		SpringApplication.run(FuelAppScheduleApplication.class, args);
	}

}
