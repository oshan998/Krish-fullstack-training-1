package com.example.inventory.controller;

public class ReservedController {

}
